/**
 * Created by ES on 2017/8/3.
 */

//x=document.getElementById("intro");
//document.write('<p>id="intro" 来点中文' + x.innerHTML + '</p>');

function moveonButton(obj){
    obj.style.color="blue";
}
function moveoutButton(obj){
    obj.style.color="red";
}
//
//x=document.getElementsByClassName("button");
//onmouseover="x.style.backgroundColor='red';";
//onmouseout="x.style.backgroundColor='blue';";